
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet' 
import 'leaflet/dist/leaflet.css'
import './mapa.css'
const pointsWithDescriptions = [
  { position: [-4.030983999114128, -79.1995964297121], uv: 2.3, fecha: '02/01/2024'},
  { position: [-4.0358037853761335, -79.20457917553198], uv: 1.8, fecha: '02/01/2024' },
  { position: [-4.036089959280352, -79.20291322714868], uv: 3.5, fecha: '02/01/2024' },
  // Agrega más puntos con sus datos según sea necesario
];

function MapaComponent() {

  return (

    <MapContainer center={[-4.033788501660946, -79.20193874829619]} zoom={17} scrollWheelZoom={false} className='mapa'>
    <TileLayer
      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
    />
    {pointsWithDescriptions.map(({ position, uv, fecha }, index) => (
      <Marker key={index} position={position}>
        <Popup>
          Uv: {uv} <br />
          Fecha: {fecha} <br />

          Coordenadas: {position[0]}, {position[1]}
        </Popup>
      </Marker>
    ))}
  </MapContainer>

  )
}

export default MapaComponent

//-4.030761, -79.199564 