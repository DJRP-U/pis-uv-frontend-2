//import Mapa from './componets/Mapa/Mapa'
import 'bootstrap/dist/css/bootstrap.min.css';
import Mapa from './Mapa/Mapa'
import '../Style/style.css';

function GestionarDisositivos() {

    return (
        <div className='pantalla_completa'>
            <div className='.container-fluid col-12'>
                <nav className="navbar navbar-expand-lg bg-body-tertiary">
                    <div className="container-fluid">
                        <a className="navbar-brand" href="#">Navegar</a>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                            s  <div className="navbar-nav">
                                <a className="nav-link active" aria-current="page" href="#">Inicio</a>
                                <a className="nav-link" href="#">Gestionar Dispositivo</a>
                                <a className="nav-link" href="#">Usuario</a>
                                <div className='center'> Nombre de Usuario</div>
                                <a className="nav-link disabled" aria-disabled="true">Cerrar sesion</a>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <div className='.container-fluid col-12'>
                <div className='col-12 d-flex flex-column h-100'>
                    <div className="btn-group-vertical col-12" role="group" aria-label="Vertical button group">

                        <button type="button" className="btn btn-primary">Agregar nuevo dispositivo</button>
                        <button type="button" className="btn btn-primary">Modificar Dispositivo</button>
                        <button type="button" className="btn btn-primary">Elminar Dispositivo</button>
                        <button type="button" className="btn btn-primary">Mostar Lista de Dispositivo</button>
                    </div>
                </div>
                <div className='col-8 d-flex flex-column h-100'>
                    <div className=''>
                        <Mapa />
                    </div>


                </div>
            </div>
        </div>
    )
}

export default GestionarDisositivos
// <Mapa/>