
import './App.css'
//import Mapa from './componets/Mapa/Mapa'
import GestionarDisositivos from './componets/GestionarDisositivos'

function App() {

  return (
    
      <div>
        <GestionarDisositivos/>
      </div>
    
  )
}

export default App
