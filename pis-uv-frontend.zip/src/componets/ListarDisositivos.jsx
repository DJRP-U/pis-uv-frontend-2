//import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../Style/style.css';
import { Link } from 'react-router-dom';
import Mapa from './Mapa/Mapa'

function ListarDispositivos() {
    // Supongamos que tienes un array de dispositivos
    const dispositivos = [
        { id: 1, latitud: '40.7128', longitud: '-74.0060' },
        { id: 2, latitud: '34.0522', longitud: '-118.2437' },
        // Puedes agregar más objetos de dispositivos aquí
    ];

    return (
        <div className="container">
            <h1 style={{ textAlign: "center" }}>DISPOSITIVOS</h1>
            {/* Resto de tu código */}
            <div className="input-group mb-3">
                <input type="text" className="form-control" placeholder="Buscar dispositivo" aria-describedby="button-addon2" />
                <button className="btn btn-outline-secondary" type="button" id="button-addon2">Buscar</button>

            </div>
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-12 mb-4 text-center">
                        <div className="btn-group" role="group">
                            <Link href="/componets/RegistrarDispositivos" className="btn btn-success font-weight-bold">Registrar</Link>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
                <div className="col-sm-10">
                    <table className="table table-sm table-bordered text-center">
                        <thead className="table-active">
                            <tr>
                                <th scope="col">Nro</th>
                                <th scope="col">Latitud</th>
                                <th scope="col">Longitud</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {dispositivos.map((dispositivo, index) => (
                                <tr key={index}>
                                    <th scope="row">{dispositivo.id}</th>
                                    <td>{dispositivo.latitud}</td>
                                    <td>{dispositivo.longitud}</td>
                                    <td>
                                        <div className="btn-group" role="group">
                                            <Link to={`/usuarios/modificar/${dispositivo.id}`} className="btn btn-warning btn-sm font-weight-bold me-2 text-white">Modificar</Link>
                                            <button type="button" className="btn btn-danger btn-sm font-weight-bold">Eliminar</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <div className='container-fluid d-flex justify-content-center align-items-center h-100'>
            <div className='col-8 d-flex flex-column h-100'>
            
                    <Mapa />
                </div>
            </div>
        </div>
    );
}

export default ListarDispositivos;









