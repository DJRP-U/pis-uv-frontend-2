//import { useState } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
//import './App.css'
//importar Menu Principal
import Menu from './componets/Menu'
import { BrowserRouter } from 'react-router-dom';
import { estaSesion } from './utilidades/Sessionutil';
//import Mapa from './componets/Mapa/Mapa'
import Login from './componets/Login'
import GestionarDisositivos from './componets/GestionarDisositivos'
import ListarDisositivos from './componets/ListarDisositivos'
import RegistrarDispositivos from './componets/RegistrarDispositivos'
import Nav from './componets/Nav'
import IndicadorUV from './componets/IndicadorUV'
import Inicio from './componets/Inicio'
import TablaDatosHistorico from './componets/TablaDatosHistorico'
import DatosHistoricos from './componets/DatosHistoricos'
import Persona from './componets/Persona'
function App() {
  const Middeware = ({ children }) => {
    const autenticado = estaSesion();
    const location = useLocation();
    if (autenticado) {
      return children;
    } else {
      return <Navigate to='/login' state={location} />;
    }
  }
  const MiddewareSesion = ({ children }) => {
    const autenticado = estaSesion();
    if (autenticado) {
      return children;
    } else {
      return <Navigate to='/' />;
    }
  }
  return (
    
    <BrowserRouter>
      <Nav/>
      <Routes>
        
        <Route path='/' element={<Inicio/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/persona' element={<MiddewareSesion><Persona/></MiddewareSesion>}/>
        <Route path='/dispositivolista' element={<ListarDisositivos/>}/>
        <Route path='/dispositivoCrear' element={<RegistrarDispositivos/>}/>
        <Route path='/dispositivo' element={<GestionarDisositivos/>}/>
        <Route path='/menu' element={<Menu/>}/>
        <Route path='/IndicadorUV' element={<IndicadorUV/>}/>
        <Route path='/TablaDatosHistorico' element={<TablaDatosHistorico/>}/>
        <Route path='/DatosHistoricos' element={<DatosHistoricos/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App