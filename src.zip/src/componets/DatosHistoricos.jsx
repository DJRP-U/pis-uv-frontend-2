import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import datosHistoricos from '../../datos.json';
import TablaDatosHistorico from './TablaDatosHistorico';

const DatosHistoricos = () => {
    const pageSize = 10;
    const maxPagesToShow = 10; // Número máximo de elementos de paginación a mostrar

    const [currentPage, setCurrentPage] = useState(1);

    // Ordenar los datos por fecha en orden descendente (de más reciente a más antiguo)
    const sortedDatosHistoricos = datosHistoricos.sort((a, b) => new Date(b.ano, b.mes - 1, b.dia) - new Date(a.ano, a.mes - 1, a.dia));

    const totalPages = Math.ceil(sortedDatosHistoricos.length / pageSize);

    const startIndex = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    const endIndex = Math.min(totalPages, startIndex + maxPagesToShow - 1);

    const currentData = sortedDatosHistoricos.slice((currentPage - 1) * pageSize, currentPage * pageSize);

    const handlePageChange = (newPage) => {
        setCurrentPage(newPage);
    };

    return (
        <div className=" mt-5">
            <div className='row'>
                <div className='col-12'>
                    <h1 className="text-center mb-4">Datos Históricos</h1>
                </div>
            </div>
            <div className='row'>
                <div className='col-5'>
                    <table className="table table-striped">
                        <thead className="thead-dark">
                            <tr>
                                <th scope="col">Hora</th>
                                <th scope="col">Día</th>
                                <th scope="col">Mes</th>
                                <th scope="col">Año</th>
                                <th scope="col">UV</th>
                            </tr>
                        </thead>
                        <tbody>
                            {currentData.map((dato, index) => (
                                <tr key={index}>
                                    <td>{dato.hora}</td>
                                    <td>{dato.dia}</td>
                                    <td>{dato.mes}</td>
                                    <td>{dato.ano}</td>
                                    <td>{dato.uv.toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <nav aria-label="Page navigation example">
                        <ul className="pagination">
                            <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                                <a className="page-link" href="#" onClick={() => handlePageChange(currentPage - 1)}>Anterior</a>
                            </li>
                            {Array.from({ length: endIndex - startIndex + 1 }, (_, index) => (
                                <li key={index} className={`page-item ${currentPage === startIndex + index ? 'active' : ''}`}>
                                    <a className="page-link" href="#" onClick={() => handlePageChange(startIndex + index)}>{startIndex + index}</a>
                                </li>
                            ))}
                            <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                                <a className="page-link" href="#" onClick={() => handlePageChange(currentPage + 1)}>Siguiente</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div className='col-6'>
                    <div className='col-12' style={{ border: '2px solid black', height: '60vh', width: '110vh', justifyContent: 'center', alignItems: 'center' }}>
                        <div className='col-12' style={{ margin: '0' }}>
                            <TablaDatosHistorico />
                        </div>
                    </div>
                </div>


            </div>
        </div>
    );
};

export default DatosHistoricos;
