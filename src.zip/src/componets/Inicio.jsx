import { useState, useEffect } from 'react';
import Mapa from './Mapa/Mapa';
import '../Style/style.css';
import datosHistoricos from '../../datos.json';
import TablaDatosHistorico from './TablaDatosHistorico';

const Inicio = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex < datosHistoricos.length - 1 ? prevIndex + 1 : 0));
    }, 1000);

    return () => clearInterval(intervalId);
  }, [currentIndex]);

  const getRiskLevel = (value) => {
    if (value >= 0 && value <= 2) {
      return 'Bajo';
    } else if (value > 2 && value <= 5) {
      return 'Moderado';
    } else if (value > 5 && value < 8) {
      return 'Alto';
    } else if (value >= 8 && value <= 11) {
      return 'Muy Alto';
    } else if (value > 11) {
      return 'Extremo';
    } else {
      return 'Error o No se encontro dato';
    }
  };

  const getColor = (riskLevel) => {
    switch (riskLevel) {
      case 'Bajo':
        return '#4CAF50'; // Verde
      case 'Moderado':
        return '#FFEB3B'; // Amarillo
      case 'Alto':
        return '#FF9800'; // Naranja
      case 'Muy Alto':
        return '#ff0000'; // Rojo
      case 'Extremo':
        return '#9C27B0'; // Púrpura
      case 'Negro':
        return '#000'; // Negro
      default:
        return '#000'; // Negro (en caso de error)
    }
  };

  const riskLevel = getRiskLevel(datosHistoricos[datosHistoricos.length - 1].uv.toFixed(2));
  const color = getColor(riskLevel);

  return (
    <div>
      <h1 style={{ textAlign: 'center' }}>Semáforo de radiación UV </h1>
      <div className='' style={{ padding: '10px' }}>
        <div className='imagen-responsiva col-4'>
          <div className='izquierda col-12' style={{ margin: '0' }}>
            <h3 style={{ textAlign: 'center' }}>Recomendación</h3>
            <img src="/src/assets/recomendacionUV.png" alt="Recomendación UV" className="imagen-responsiva" />
          </div>
        </div>
        <div className='imagen-responsiva col-8 '>
          <div className='row'>
            <div className='col-4'>
              <div className='col-12'>
                <h3 style={{ textAlign: 'center' }}>Nivel de Riesgo UV </h3>
              </div>
              <div style={{ padding: '5px' }}>
                <div className='container' style={{ backgroundColor: color, border: '5px solid black', height: '20vh', width: '20vw', justifyContent: 'center', alignItems: 'center' }}>
                  <div style={{ whiteSpace: 'pre-line' }}>
                    <h1 style={{ textAlign: 'center', fontSize: '5em' }}>{datosHistoricos[datosHistoricos.length - 1].uv.toFixed(2)}</h1>
                  </div>
                  <div style={{ whiteSpace: 'pre-line' }}>
                    <h2 style={{ textAlign: 'center' }}> {riskLevel}</h2>
                  </div>
                </div>
              </div>
            </div>
            <div className='col-8'>
              <h2 style={{ textAlign: 'center' }}>Ubicación de sensores UV </h2>
              <div className='col-12' style={{ border: '1px solid black', height: '51vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <Mapa />
              </div>
            </div>
            <div className='col-8'>
              <h2>Datos de radiación recolectados</h2>
              <div className='col-12' style={{ border: '2px solid black', height: '72vh', width: '135vh', justifyContent: 'center', alignItems: 'center' }}>
              <div className='col-12' style={{ margin: '0' }}>
                    <TablaDatosHistorico/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inicio;
