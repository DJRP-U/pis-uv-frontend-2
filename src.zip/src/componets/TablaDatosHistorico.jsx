import { useEffect, useState, useRef } from 'react';
import Chart from 'chart.js/auto';
import 'bootstrap/dist/css/bootstrap.min.css';

const TablaDatosHistorico = () => {
  const [vista, setVista] = useState('24horas');
  const [datosHistoricos, setDatosHistoricos] = useState([]);
  const chartRef = useRef(null);

  const cambiarVista = (nuevaVista) => {
    setVista(nuevaVista);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('../../datos.json');
        const data = await response.json();
        setDatosHistoricos(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (datosHistoricos.length > 0 && chartRef.current) {
      const ctx = chartRef.current.getContext('2d');

      const labels = obtenerLabels(vista, datosHistoricos);
      const datos = obtenerDatos(vista, datosHistoricos);
      const colores = obtenerColores(datos);

      const myChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'Valor de UV',
            data: datos,
            backgroundColor: colores,
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            x: {
              type: 'category',
              offset: true,
              grid: {
                display: false
              },
              ticks: {
                maxRotation: 0,
                autoSkip: true,
                maxTicksLimit: 24 // Mostrar solo 24 etiquetas para las últimas 24 horas
              }
            },
            y: {
              beginAtZero: true
            }
          }
        }
      });

      return () => {
        myChart.destroy();
      };
    }
  }, [vista, datosHistoricos]);

  return (
    <div>
      <div>
        <button onClick={() => cambiarVista('24horas')}>24 Horas</button>
        {/* Otros botones de vista si es necesario */}
      </div>
      <canvas ref={chartRef}></canvas>
    </div>
  );
};

const obtenerLabels = (vista, datos) => {
  let datosFiltrados = [...datos];

  switch (vista) {
    case '24horas':
      // Obtener solo los datos de las últimas 24 horas
      datosFiltrados = datosFiltrados.slice(-24);
      break;
    // Agregar casos para otras vistas si es necesario
    default:
      break;
  }

  return datosFiltrados.map(data => data.hora);
};

const obtenerDatos = (vista, datos) => {
  let datosFiltrados = [...datos];

  switch (vista) {
    case '24horas':
      // Obtener solo los datos de las últimas 24 horas
      datosFiltrados = datosFiltrados.slice(-24);
      break;
    // Agregar casos para otras vistas si es necesario
    default:
      break;
  }

  return datosFiltrados.map(data => data.uv);
};

const obtenerColores = (datos) => {
  return datos.map(uv => {
    // Definir los colores según el valor de UV
    if (uv >= 0 && uv <= 2) {
      return 'rgba(0, 128, 0, 0.5)'; // Verde
    } else if (uv > 2 && uv <= 5) {
      return 'rgba(255, 255, 0, 0.5)'; // Amarillo
    } else if (uv > 5 && uv <= 7) {
      return 'rgba(255, 165, 0, 0.5)'; // Naranja
    } else if (uv > 7 && uv <= 10) {
      return 'rgba(255, 0, 0, 0.5)'; // Rojo
    } else if (uv > 10) {
      return 'rgba(238, 130, 238, 0.5)'; // Violeta
    } else {
      return 'rgba(0, 0, 0, 0.5)'; // Valor inválido
    }
  });
};

export default TablaDatosHistorico;
