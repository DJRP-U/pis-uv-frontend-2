import { useState } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Form } from 'react-bootstrap';

const AgregarUsuarioModal = ({ show, handleClose }) => {
    const [usuario, setUsuario] = useState({
        nombres: '',
        apellidos: '',
        identificacion: '',
        direccion: '',
        telefono: '',
        rol: '',
        correo: '',
        clave: '',
    });

    const roles = ['Desarrollador', 'Administrador', 'Estudiante', 'Brigadista'];
    const [error, setError] = useState('');

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setUsuario({
            ...usuario,
            [name]: value,
        });
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await fetch('http://localhost:8095/api/v1/personas/guardar', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    nombres: usuario.nombres,
                    apellidos: usuario.apellidos,
                    identificacion: usuario.identificacion,
                    direccion: usuario.direccion,
                    telefono: usuario.telefono,
                    tipo_persona: usuario.rol,
                    cuenta: {
                        correo: usuario.correo,
                        clave: usuario.clave,
                    },
                }),
            });
            const data = await response.json();

            if (response.ok) {
                console.log('Usuario registrado exitosamente:', data);
                handleClose();
            } else {
                console.error('Error al registrar usuario:', data);
                setError(data.data.evento);
            }
        } catch (error) {
            console.error('Error al enviar la solicitud:', error);
            setError('Error al enviar la solicitud');
        }
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Agregar Usuario</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form onSubmit={handleSubmit}>
                    <Form.Group controlId="formNombres">
                        <Form.Label>Apellidos:</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Ingresa nombres"
                            name="nombres"
                            value={usuario.nombres}
                            onChange={handleInputChange}
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formApellidos">
                        <Form.Label>Nombres:</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Ingresa apellidos"
                            name="apellidos"
                            value={usuario.apellidos}
                            onChange={handleInputChange}
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formDireccion">
                        <Form.Label>Direccion:</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Ingresa su direccion"
                            name="identificacion"
                            value={usuario.identificacion}
                            onChange={handleInputChange}
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formTelefono">
                        <Form.Label>Fecha_nacimiento:</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Ingresa la fecha de nacimiento"
                            name="telefono"
                            value={usuario.telefono}
                            onChange={handleInputChange}
                            required
                        />
                    </Form.Group>


                    
                    <Form.Group controlId="formTelefono">
                        <Form.Label>Ocupacion:</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Ingresa número de teléfono"
                            name="telefono"
                            value={usuario.telefono}
                            onChange={handleInputChange}
                            required
                        />
                    </Form.Group>

                    

                    <Form.Group controlId="formCorreo">
                        <Form.Label>Usuario:</Form.Label>
                        <Form.Control
                            type="email"
                            placeholder="Ingresa correo electrónico"
                            name="correo"
                            value={usuario.correo}
                            onChange={handleInputChange}
                            required
                        />
                    </Form.Group>

                    

                    <Button variant="primary" type="submit">
                        Agregar Usuario
                    </Button>
                </Form>
                {error && (
                    <p className="text-danger mt-3">
                        {error === 'La identificación ya está registrada' ? 'La identificación ya está registrada.' : 
                         error === 'El teléfono ya está registrado' ? 'El teléfono ya está registrado.' : 
                         error === 'El correo ya está registrado' ? 'El correo electrónico ya está registrado.' :
                         'Ocurrió un error. Por favor, inténtalo de nuevo más tarde.'}
                    </p>
                )}
            </Modal.Body>
        </Modal>
    );
};

AgregarUsuarioModal.propTypes = {
    show: PropTypes.bool.isRequired,
    handleClose: PropTypes.func.isRequired,
};

export default AgregarUsuarioModal;
